# Wind_data

The original goal of this library was to get an easy pipeline to get wind data from Era_interim, and now Era 5,
deal with the data and get sand fluxes distributions. Most of it comes from example scripts that you can find of the documentation pages
of these two projects.

Feel free to use it, and modify it as much as you like. However, please keep me updated of any changes you make and bugs you solve such
that I can add them to the repository.

This library has been written by Cyril GADAL (Institut de Physique du Globe de Paris).
