# @Author: gadal
# @Date:   2020-12-01T12:03:10+01:00
# @Email:  gadal@ipgp.fr
# @Last modified by:   gadal
# @Last modified time: 2020-12-01T12:23:04+01:00

"""
Wind data main file
"""

__author__ = "Cyril Gadal"
__copyright__ = "Copyright 2018"
__license__ = "GPL"
__version__ = "0.1"

__all__ = ['Era_5', 'Wind_treatment']
